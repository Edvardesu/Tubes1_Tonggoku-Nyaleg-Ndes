export type BaseGameObjectProperties = {
  name: string;
};
