export interface TeleportRelocationProviderConfig {
  /**
   * The number of seconds to wait before relocating teleporters.
   */
  seconds: number;
}
