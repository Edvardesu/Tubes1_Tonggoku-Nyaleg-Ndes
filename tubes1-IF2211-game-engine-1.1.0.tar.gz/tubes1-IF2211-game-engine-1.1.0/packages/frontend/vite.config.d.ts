declare const _default: ({ mode }: {
    mode: any;
}) => import("vite").UserConfig;
export default _default;
