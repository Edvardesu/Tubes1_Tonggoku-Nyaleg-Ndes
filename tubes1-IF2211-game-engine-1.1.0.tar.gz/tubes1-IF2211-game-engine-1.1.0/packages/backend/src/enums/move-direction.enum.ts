export enum MoveDirection {
  NORTH = "NORTH",
  SOUTH = "SOUTH",
  WEST = "WEST",
  EAST = "EAST",
}
